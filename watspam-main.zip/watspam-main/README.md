# WatSpam
```
Tools ini dibuat untuk ngerjain
Kang Ripper atau boleh juga buat
nyepam Mantan Lu awokawokwkwk:v
```
> Script ini sewaktu-waktu bisa jadi limit ataupun coid jadi jangan salahin author nya ya goblok.
## How to it?
```python
$ cd watspam
$ python -m pip install -r requirements.txt
$ python wa.py
```
> Get Token [click here](https://cararegistrasi.com/TokenWatSpam)
## Support Me On
<b>• [Facebook](https://m.facebook.com/dhasilva.junior.3)</b>
<br>
<b>• [Youtube](https://www.youtube.com/channel/UCLRXFyMN0L8yH9F-xxOd7Og)</b>
</br>
